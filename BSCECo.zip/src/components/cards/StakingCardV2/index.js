import React, { useState, useEffect } from "react";
import { Card, Col, Container, Row, Input } from "reactstrap";
import { utils } from "ethers";
import styles from "../StakingCardV2/StakingCard.module.css";
import { toast } from "react-toastify";
import TokenIcon from "../../common/TokenIcon";
import Button from "../../common/Button";
import StakingModal from "../../../views/StakingV2/StakingComponent";
import UnstakingModal from "../../../views/StakingV2/UnstakingComponent";
import ConfirmationModal from "../../modals/ConfirmationModal";
const countsPerPeriod = (e, aprValue) => {
  switch (e) {
    // case "1m":
    //   return { _seconds: 60, aprValuePerPeriod: aprValue / (12*30*24*60) };
    // case "1h":
    //   return { _seconds: 3600, aprValuePerPeriod: aprValue / (12*30*24) };
    case "1M":
      return { _seconds: 86400 * 30, aprValuePerPeriod: aprValue / 12 };
    case "2M":
      return { _seconds: 86400 * 30 * 2, aprValuePerPeriod: (aprValue / 12) * 2 };
    case "3M":
      return { _seconds: 86400 * 30 * 3, aprValuePerPeriod: (aprValue / 12) * 3 };
    case "6M":
      return { _seconds: 86400 * 30 * 6, aprValuePerPeriod: (aprValue / 12) * 6 };
    case "1Y":
      return { _seconds: 86400 * 30 * 12, aprValuePerPeriod: (aprValue / 12) * 12 };
    case "2Y":
      return { _seconds: 86400 * 30 * 12 * 2, aprValuePerPeriod: (aprValue / 12) * 12 * 2 };
    case "3Y":
      return { _seconds: 86400 * 30 * 12 * 3, aprValuePerPeriod: (aprValue / 12) * 12 * 3 };
    case "3Y":
      return { _seconds: 86400 * 30 * 12 * 4, aprValuePerPeriod: (aprValue / 12) * 12 * 4 };
    case "4Y":
      return { _seconds: 86400 * 30 * 12 * 4, aprValuePerPeriod: (aprValue / 12) * 12 * 4 };
    default:
      break;
  }
};

const StakingCard = ({
  disabled,
  tokenName,
  rewardTokenName,
  tokenIcon,
  aprValue,
  totalStaked,
  totalStaker,
  stakeAmount,
  walletBalance,
  walletAmount,
  updateWalletAmount,
  checkAndUnstake,
  buyUrl,
  checkAndStakeToken,
  updateCountPerPeriod,
  lockTime,
  totalEarned,
  checkAndHarvestToken,
  totalPending,
  aprValuePeriodically,
}) => {
  const MAX_BALANCE = 500000;

  const openInNewWindow = (url) => {
    const newWindow = window.open(url);
  };

  const setMaxAmount = () => {
    walletBalance < MAX_BALANCE ? updateWalletAmount(walletBalance) : updateWalletAmount(MAX_BALANCE);
  };

  const handleStakeToggle = () => {
    updateWalletAmount("");
  };

  const handleUnstakeToggle = () => {
    updateWalletAmount("");
  };

  const toMax4Decimals = (x) => {
    return +x.toFixed(4);
  };

  const pills = [/* "1m", "1h",  */ "1M", "2M", "3M", "6M", "1Y", "2Y", "3Y", "4Y"];
  const defaultPill = pills[0];
  const [selectedChip, setSelectedChip] = useState(defaultPill);
  const [stake, setStake] = useState(false);
  const [unstake, setUnstake] = useState(false);
  useEffect(() => {
    updateCountPerPeriod(countsPerPeriod(selectedChip, aprValue));
  }, [aprValue]);

  const setStakeSection = () => {
    setStake(!stake);
    setUnstake(false);
  };
  const setUnstakeSection = () => {
    setStake(false);
    setUnstake(!unstake);
  };
  console.log(stake);
  return (
    <>
      <Card className={styles.stakingCard} style={{ pointerEvents: disabled && "none", opacity: disabled && "0.7" }}>
        <Container className="p-3">
          <Row className="mt-2 mb-3">
            <Col xs={3} className="text-end">
              <TokenIcon image={tokenIcon} />
            </Col>
            <Col xs={9} className="d-flex align-items-center text-center">
              <h3>Stake {tokenName}</h3>
            </Col>
          </Row>
          <Row>
            <Col xs={12}>
              <div className={styles.infoGrid}>
                <div>
                  <div>APR</div>
                  <div className={styles.infoValue}>{aprValue}%</div>
                </div>
                {/* <div>
                  <div>TOTAL STAKED</div>
                  <div className={styles.infoValue}>${totalStaked}</div>
                </div>
                <div>
                  <div>TOTAL STAKERS</div>
                  <div className={styles.infoValue}>{totalStaker}</div>
                </div> */}
              </div>
            </Col>
          </Row>
          <Row>
            <Col xs={12}>
              <div className={styles.stakeDiv}>
                <div className={styles.buttonsDiv}>
                  <div style={{ maxWidth: 120 }}>
                    <div>{tokenName} STAKED</div>
                  </div>
                  <div className={styles.buttons}>
                    <div>
                      {/* <UnstakingModal
                        style={{ margin: "5px", minWidth: "100px" }}
                        tokenName={tokenName}
                        toggle={handleUnstakeToggle}
                        walletBalance={walletBalance}
                        walletAmount={walletAmount}
                        updateWalletAmount={updateWalletAmount}
                        stakeAmount={stakeAmount}
                        checkAndUnstake={checkAndUnstake}
                      />*/}
                      <Button onClick={() => setUnstakeSection()} style={{ margin: "5px", minWidth: "100px" }}>
                        Unstake
                      </Button>
                    </div>

                    <div>
                      {/* <StakingModal
                        style={{ margin: "5px", minWidth: "100px" }}
                        tokenName={tokenName}
                        buyUrl={buyUrl}
                        checkAndStakeToken={checkAndStakeToken}
                        walletBalance={walletBalance}
                        walletAmount={walletAmount}
                        toggle={handleStakeToggle}
                        updateWalletAmount={updateWalletAmount}
                        updateCountPerPeriod={updateCountPerPeriod}
                        lockTime={lockTime}
                        aprValue={aprValue}
                        aprValuePeriodically={aprValuePeriodically}
                      /> */}
                      <Button onClick={() => setStakeSection()} style={{ margin: "5px", minWidth: "100px" }}>
                        Stake
                      </Button>
                    </div>
                  </div>
                </div>
                <div className={styles.zero}>{stakeAmount ? stakeAmount : 0.0}</div>
              </div>
            </Col>
          </Row>

          <Row>
            <Col xs={12} className={`${stake ? styles.showStake : styles.hideStake} mt-5 mb-5`}>
              <div className={styles.infoText}>
                <div>Balance in Wallet : {utils.commify(toMax4Decimals(parseFloat(walletBalance)))}</div>
              </div>
              <div className={styles.inputSection}>
                <Input
                  type="text"
                  placeholder="Enter Amount"
                  className={styles.input}
                  value={walletAmount}
                  onChange={(e) => updateWalletAmount(e.target.value)}
                />
                <Button style={{ marginLeft: "5px" }} buttonStyle="btnStyle" onClick={() => setMaxAmount()}>
                  Max
                </Button>
              </div>
              <div className={styles.infoText + " mt-3"}>
                <div>
                  Estimated APR : <span className={styles.percentage}>{aprValuePeriodically ? toMax4Decimals(aprValuePeriodically) : 0}%</span>
                </div>
              </div>

              <div className={styles.pills}>
                {pills.map((option) => {
                  const style =
                    selectedChip && selectedChip === option ? { border: "1px solid #007bff", color: "#ffffff", backgroundColor: "#007bff" } : {};
                  return (
                    <div>
                      <button
                        key={option}
                        value={option}
                        style={style}
                        className={option === selectedChip ? styles.activePill : ""}
                        onClick={(e) => {
                          setSelectedChip(e.target.value);
                          updateCountPerPeriod(countsPerPeriod(e.target.value, aprValue));
                        }}
                      >
                        {option}
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className={styles.buttonSection + " mt-2"}>
                <Row>
                  <Col>
                    <Button
                      buttonStyle="btnStyle2"
                      buttonSize="largeBtn"
                      onClick={() => {
                        checkAndStakeToken();
                      }}
                    >
                      Stake
                    </Button>
                  </Col>
                  <Col>
                    <Button
                      buttonStyle="btnStyle3"
                      style={{ marginTop: "10px" }}
                      onClick={() => {
                        openInNewWindow(buyUrl);
                      }}
                    >
                      Buy {tokenName}
                    </Button>
                  </Col>
                </Row>
              </div>
            </Col>
          </Row>

          <Row>
            <Col xs={6}>
              <div className={styles.pending}>
                <div>{rewardTokenName} EARNED</div>
                <div className={styles.zero}>{totalEarned}</div>
                <div>~ 0.0 USD</div>
              </div>
            </Col>
            <Col xs={6}>
              <div className={styles.pending}>
                <div>{rewardTokenName} PENDING</div>
                <div className={styles.zero}>{totalPending}</div>
                <div>~ 0.0 USD</div>
              </div>
            </Col>
          </Row>
          <Row>
            <Col>
              <ConfirmationModal
                message={"Are you sure you want to claim pending tokens?"}
                style={{ margin: "5px", minWidth: "100px" }}
                onConfirm={() => {
                  if (Number(totalPending) !== 0) {
                    checkAndHarvestToken();
                  } else {
                    toast.error("Pending Amount is Null");
                  }
                }}
              >
                <Button buttonStyle="btnStyle2" buttonSize="largeBtn">
                  Harvest
                </Button>
              </ConfirmationModal>
            </Col>
          </Row>
        </Container>
      </Card>
    </>
  );
};

export default StakingCard;
